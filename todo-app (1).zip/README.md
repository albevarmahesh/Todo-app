# Full Stack Todo App

Spring Boot + React Todo application.

## Backend
cd backend
mvn spring-boot:run

Runs on http://localhost:8080

## Frontend
cd frontend
npm install
npm start

Runs on http://localhost:3000