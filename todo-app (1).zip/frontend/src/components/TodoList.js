import { useEffect, useState } from "react";
import API from "../api";
import TodoItem from "./TodoItem";
import TodoForm from "./TodoForm";

export default function TodoList() {
  const [todos, setTodos] = useState([]);

  const load = async () => {
    const res = await API.get("/");
    setTodos(res.data);
  };

  useEffect(() => { load(); }, []);

  const addTodo = async todo => {
    await API.post("/", todo);
    load();
  };

  const updateTodo = async (id, todo) => {
    await API.put(`/${id}`, todo);
    load();
  };

  const deleteTodo = async id => {
    await API.delete(`/${id}`);
    load();
  };

  return (
    <div>
      <h2>Todo App</h2>
      <TodoForm addTodo={addTodo} />
      {todos.map(t => (
        <TodoItem
          key={t.id}
          todo={t}
          update={updateTodo}
          remove={deleteTodo}
        />
      ))}
    </div>
  );
}