export default function TodoItem({ todo, update, remove }) {
  return (
    <div>
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() =>
          update(todo.id, { ...todo, completed: !todo.completed })
        }
      />
      {todo.title}
      <button onClick={() => remove(todo.id)}>Delete</button>
    </div>
  );
}